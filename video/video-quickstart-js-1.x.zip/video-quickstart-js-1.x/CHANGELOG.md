# 1.0.0
=======

* Added an example app to demonstrate Codec Preferences API.
* Added an example app to demonstrate Bandwidth Constraints API.
* Added an example app to demonstrate Local Video Filter.
* Added an example app to demonstrate Local Video Snapshot.
* Added an example app to demonstrate Media Device Selection.
* Updated twilio-video to 1.0.0.
* Removed configuration profile.
* Consolidated the various twilio-video.js quickstarts into a single project.
